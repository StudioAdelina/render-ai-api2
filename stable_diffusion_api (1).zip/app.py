
from flask import Flask, request, jsonify, send_file
from diffusers import StableDiffusionPipeline
import torch
import uuid
import os

app = Flask(__name__)

pipe = StableDiffusionPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    torch_dtype=torch.float16,
    use_auth_token=True
).to("cuda" if torch.cuda.is_available() else "cpu")

@app.route("/generate", methods=["POST"])
def generate_image():
    data = request.json
    prompt = data.get("prompt", "Modern living room interior, minimal, white, wood, black")
    image = pipe(prompt).images[0]

    filename = f"{uuid.uuid4().hex}.png"
    image_path = os.path.join("/tmp", filename)
    image.save(image_path)
    return send_file(image_path, mimetype='image/png')

@app.route("/", methods=["GET"])
def home():
    return jsonify({"message": "Stable Diffusion is ready."})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
